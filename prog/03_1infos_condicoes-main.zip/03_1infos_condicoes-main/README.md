# 03_1infos_condicoes
Lista de Exercícios - Condições [02]

Os exercícios servirão de preparação para a prova sobre Condições, a ser realizada no Segundo Trimestre.
